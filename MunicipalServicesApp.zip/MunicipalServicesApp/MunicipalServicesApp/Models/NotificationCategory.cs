﻿namespace MunicipalServicesApp.Models
{
    public enum NotificationCategory
    {
        ServiceUpdate,
        Emergency,
        Event,
        General
    }
}