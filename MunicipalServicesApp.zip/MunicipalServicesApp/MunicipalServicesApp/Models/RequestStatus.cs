﻿namespace MunicipalServicesApp.Models
{
    public enum RequestStatus
    {
        Submitted,
        InProgress,
        Resolved,
        Closed
    }
}